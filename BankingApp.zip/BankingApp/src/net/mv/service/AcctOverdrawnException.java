package net.mv.service;

public class AcctOverdrawnException extends Exception {
	public AcctOverdrawnException() {		
	}
	
	public AcctOverdrawnException(String message) {
		super(message);
	}
	
}
